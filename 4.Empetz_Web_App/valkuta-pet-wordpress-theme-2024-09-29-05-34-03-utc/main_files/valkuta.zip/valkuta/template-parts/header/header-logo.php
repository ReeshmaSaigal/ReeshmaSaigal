<?php
if(is_page() || is_singular('post') || valkuta_custom_post_types() && get_post_meta($post->ID, 'valkuta_common_meta', true)) {
	$common_meta = get_post_meta($post->ID, 'valkuta_common_meta', true);
}else{
	$common_meta = array();
}

if (is_array($common_meta) && array_key_exists('header_logo_meta', $common_meta) && !empty($common_meta['header_logo_meta']['url'])) {
	$site_logo_img = $common_meta['header_logo_meta'];
} else  {
	$site_logo_img = valkuta_option('header_default_logo','');
	$site_mobile_logo_img = valkuta_option('mobile_logo','');
}

?>

<div class="site-branding">
	<div class="logo-wrap<?php if (!empty($site_mobile_logo_img['url'])){ echo ' mobile-logo-enable';}?>">
		<?php
		if(has_custom_logo()){
			the_custom_logo();
		}else{
			if(!empty($site_logo_img['url'])){ ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <img class="desktop-logo" src="<?php echo esc_url($site_logo_img['url']); ?>" alt="<?php esc_attr(bloginfo( 'name' )); ?>">
					<?php if(!empty($site_mobile_logo_img['url'])){ ?>
                        <img class="mobile-logo" src="<?php echo esc_url($site_mobile_logo_img['url']); ?>" alt="<?php esc_attr(bloginfo( 'name' )); ?>">
					<?php } ?>
                </a>
				<?php

			}else{ ?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>

				<?php

			}
		}
		?>
	</div>
</div>