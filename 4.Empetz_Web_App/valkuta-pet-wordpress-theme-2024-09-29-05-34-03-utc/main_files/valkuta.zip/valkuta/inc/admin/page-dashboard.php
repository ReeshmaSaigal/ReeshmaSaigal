<?php if (!defined('ABSPATH')) {
	die;
} // Cannot access directly. ?>

<div class="wrap td-wrap">

    <div class="td-admin-page-header">

        <div class="td-admin-page-header-text">
            <h1><?php esc_html_e('Welcome to Valkuta!', 'valkuta'); ?></h1>
            <p><?php esc_html_e('Valkuta is a WordPress theme for pet care service', 'valkuta'); ?></p>
        </div>

        <div class="td-admin-page-header-logo">
            <img src="<?php echo get_theme_file_uri('inc/admin/assets/images/admin-logo.png'); ?>"/>
            <strong>V-<?php echo wp_get_theme()->get('Version'); ?></strong>
        </div>
    </div>

    <div class="td-admin-boxes">

        <div class="td-admin-box">

            <div class="td-admin-box-header">
                <h2><?php esc_html_e('Theme Documentation', 'valkuta'); ?></h2>
            </div>

            <div class="td-admin-box-inside">
                <p><?php esc_html_e('You can find everything about theme settings. See our online documentation.', 'valkuta'); ?></p>
                <a href="https://docs.themedraft.net/wp/valkuta/" target="_blank"
                   class="button"><?php esc_html_e('Go to Documentation', 'valkuta'); ?></a>
            </div>

        </div>

        <div class="td-admin-box">

            <div class="td-admin-box-header">
                <h2><?php esc_html_e('Theme Support', 'valkuta'); ?></h2>
            </div>

            <div class="td-admin-box-inside">
                <p><?php esc_html_e('Do you need help? Feel to free ask any question.', 'valkuta'); ?></p>
                <a href="https://themeforest.net/item/valkuta-pet-wordpress-theme/25797080/support" target="_blank"
                   class="button"><?php esc_html_e('Contact Support', 'valkuta'); ?></a>
            </div>
        </div>

    </div>

</div>
