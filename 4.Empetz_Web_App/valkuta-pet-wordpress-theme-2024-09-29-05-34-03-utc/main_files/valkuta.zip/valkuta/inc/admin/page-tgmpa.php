<?php

function valkuta_install_required_plugins() {

	$plugins = array(

		array(
			'name'     => esc_html__('Breadcrumb NavXT', 'valkuta'),
			'slug'     => 'breadcrumb-navxt',
			'version'  => '7.3.1',
			'required' => false,
		),

		array(
			'name'     => esc_html__('Codestar Framework', 'valkuta'),
			'slug'     => 'codestar-framework',
			'source'   => get_template_directory(). '/inc/plugins/codestar-framework.zip',
			'version'  => '2.3.1',
			'required' => true
		),


		array(
			'name'     => esc_html__('Contact Form 7', 'valkuta'),
			'slug'     => 'contact-form-7',
			'version'  => '5.9.8',
			'required' => false
		),

		array(
			'name'     => esc_html__('Elementor Page Builder', 'valkuta'),
			'slug'     => 'elementor',
			'version'  => '3.24.4',
			'required' => true,
		),

		array(
			'name'     => esc_html__('Mailchimp for WordPress', 'valkuta'),
			'slug'     => 'mailchimp-for-wp',
			'version'  => '4.9.17',
			'required' => false,
		),

		array(
			'name'     => esc_html__('One Click Demo Import', 'valkuta'),
			'slug'     => 'one-click-demo-import',
			'version'  => '3.2.1',
			'required' => false,
		),


		array(
			'name'     => esc_html__('ThemeDraft Core', 'valkuta'),
			'slug'     => 'themedraft-core',
			'source'   => get_template_directory(). '/inc/plugins/themedraft-core.zip',
			'version'  => '1.2.6',
			'required' => true
		),

		array(
			'name'     => esc_html__('WooCommerce', 'valkuta'),
			'slug'     => 'woocommerce',
			'version'  => '9.3.3',
			'required' => false,
		),

		array(
			'name'     => esc_html__('YITH WooCommerce Quick View', 'valkuta'),
			'slug'     => 'yith-woocommerce-quick-view',
			'version'  => '1.43.0',
			'required' => false,
		),

	);

	$config = array(
		'id'           => 'valkuta',
		'parent_slug'  => 'valkuta',
		'menu'         => 'valkuta-plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'is_automatic' => false,
		'dismiss_msg'  => '',
		'message'      => '',
		'default_path' => '',
	);

	tgmpa($plugins, $config);
}

add_action('tgmpa_register', 'valkuta_install_required_plugins');