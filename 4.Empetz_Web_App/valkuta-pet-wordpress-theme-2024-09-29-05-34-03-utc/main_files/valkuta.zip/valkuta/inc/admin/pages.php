<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Valkuta Admin Pages
 *
 */
if ( ! class_exists( 'Valkuta_Admin' ) ) {

	class Valkuta_Admin{
		private static $instance = null;

		public static function init() {
			if( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		public function __construct() {

			add_action( 'init', array( $this, 'valkuta_create_tgmpa_page' ), 1 );
			add_action( 'admin_menu', array( $this, 'valkuta_create_admin_page' ), 1 );
			add_action( 'admin_enqueue_scripts', array( $this, 'valkuta_admin_page_enqueue_scripts' ) );

			add_filter( 'ocdi/plugin_page_setup', array( $this, 'valkuta_pt_ocdi_page_setup' ) );

		}

		public function valkuta_create_admin_page() {
			add_menu_page( esc_html__( 'Valkuta', 'valkuta' ), esc_html__( 'Valkuta', 'valkuta' ), 'manage_options', 'valkuta', array( $this, 'valkuta_admin_page_dashboard' ), 'dashicons-screenoptions', 2 );
			add_submenu_page( 'valkuta', esc_html__( 'Welcome', 'valkuta' ), esc_html__( 'Welcome & Support', 'valkuta' ), 'manage_options', 'valkuta', array( $this, 'valkuta_admin_page_dashboard' ) );
		}

		public function valkuta_admin_page_dashboard() {
			require_once VALKUTA_INC_DIR .'admin/page-dashboard.php';
		}

		public function valkuta_create_tgmpa_page() {
			require_once VALKUTA_INC_DIR .'admin/class-tgm-plugin-activation.php';
			require_once VALKUTA_INC_DIR .'admin/page-tgmpa.php';
		}

		public function valkuta_admin_page_enqueue_scripts() {
			wp_enqueue_style( 'valkuta-admin', get_theme_file_uri( 'inc/admin/assets/css/admin.css' ), array(), VALKUTA_VERSION, 'all' );
		}

		public function valkuta_pt_ocdi_page_setup( $args ) {

			$args['parent_slug'] = 'valkuta';
			$args['menu_slug']   = 'valkuta-import-demo';
			$args['menu_title']  = esc_html__( 'Import Demo', 'valkuta' );
			$args['capability']  = 'manage_options';

			return $args;

		}

	}

	Valkuta_Admin::init();
}